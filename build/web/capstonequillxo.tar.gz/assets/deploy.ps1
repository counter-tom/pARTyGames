# deploy.ps1 — commit this to git
. .\deploy_config.ps1

python -m pygbag --build .
Copy-Item ".\build\web\index.html" ".\build\web\game.html" -Force
Copy-Item $LOGIN_PAGE ".\build\web\index.html" -Force
scp -i $PEM_PATH -r ".\build\web\." "ubuntu@${54.198.158.137}:/var/www/html/"