# deploy_config.ps1 — fill in your own paths
# Add this file to .gitignore

$PEM_PATH      = "C:\Users\Daniel M\Documents\AWS\Spring2026SP_McKee_1.pem"
$LOGIN_PAGE    = "C:\Users\Daniel M\Documents\Senior Project\indexKEEP.html"
$GAME_PAGE     = "C:\Users\Daniel M\Documents\Senior Project\gameKEEP.html"
$CALLBACK_PAGE = "C:\Users\Daniel M\Documents\Senior Project\callbackKEEP.html"
$EC2_IP        = "54.198.158.137"