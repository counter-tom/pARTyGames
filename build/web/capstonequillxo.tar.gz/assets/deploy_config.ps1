# deploy_config.ps1 — EACH TEAMMATE FILLS THIS IN FOR THEIR OWN MACHINE
# Add this file to .gitignore

$PEM_PATH = "C:\Users\Daniel M\Documents\AWS\Spring2026SP_McKee_1.pem"
$LOGIN_PAGE = "C:\Users\Daniel M\Documents\BackupIndex\index.html"
$EC2_IP = "54.198.158.137"